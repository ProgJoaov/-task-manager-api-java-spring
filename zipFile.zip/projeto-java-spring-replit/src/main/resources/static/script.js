const form = document.getElementById("form");
const input = document.getElementById("titulo");
const lista = document.getElementById("lista");

async function carregarTarefas() {
  const resposta = await fetch("/api/tarefas");
  const tarefas = await resposta.json();

  lista.innerHTML = "";

  tarefas.forEach((tarefa) => {
    const item = document.createElement("li");
    if (tarefa.concluida) item.classList.add("concluida");

    item.innerHTML = `
      <span>${tarefa.titulo}</span>
      <div class="actions">
        <button onclick="alternar(${tarefa.id})">OK</button>
        <button class="delete" onclick="remover(${tarefa.id})">Excluir</button>
      </div>
    `;

    lista.appendChild(item);
  });
}

form.addEventListener("submit", async (evento) => {
  evento.preventDefault();

  await fetch("/api/tarefas", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ titulo: input.value })
  });

  input.value = "";
  carregarTarefas();
});

async function alternar(id) {
  await fetch(`/api/tarefas/${id}/alternar`, { method: "PATCH" });
  carregarTarefas();
}

async function remover(id) {
  await fetch(`/api/tarefas/${id}`, { method: "DELETE" });
  carregarTarefas();
}

carregarTarefas();
