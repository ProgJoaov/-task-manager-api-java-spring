package com.joaovitor.tarefas;

public class TarefaRequest {
    private String titulo;

    public TarefaRequest() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
