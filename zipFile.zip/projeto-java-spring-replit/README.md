# Projeto Java + Spring Boot - Sistema de Tarefas

Projeto simples para portfólio, feito com Java 11 e Spring Boot.

## Tecnologias

- Java 11
- Spring Boot
- Maven
- API REST
- HTML, CSS e JavaScript

## Como rodar no Replit

No Shell, execute:

```bash
mvn spring-boot:run
```

Se o Replit perguntar para instalar Maven pelo Nix, responda:

```txt
y
```

Depois abra o Preview.

## Funcionalidades

- Listar tarefas
- Criar tarefas
- Marcar como concluída
- Excluir tarefas

## Como colocar no currículo

Projeto Java com Spring Boot para gerenciamento de tarefas, com API REST e interface web simples. Implementação de CRUD, organização em camadas básicas e uso de Maven para gerenciamento do projeto.
